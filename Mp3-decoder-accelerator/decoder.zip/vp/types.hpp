#ifndef _TYPES_H_
#define _TYPES_H_

#define SC_INCLUDE_FX

#include <systemc>

typedef sc_dt::sc_fixed_fast<15, 5, sc_dt::SC_RND> fixed_point;

#endif
